package com.prisha.myapplication;

public class UserInformation {
    public String latitude;
    public String longitude;
    public String name;
    public String location;
    public String type;
}
